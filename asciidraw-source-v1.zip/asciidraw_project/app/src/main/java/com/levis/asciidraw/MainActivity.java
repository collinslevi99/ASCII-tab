package com.levis.asciidraw;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;

public class MainActivity extends Activity {
  @Override
  public void onCreate(Bundle b) {
    super.onCreate(b);
    WebView w = new WebView(this);
    w.setBackgroundColor(0xff0b0b0b);
    WebSettings s = w.getSettings();
    s.setJavaScriptEnabled(true);
    s.setDomStorageEnabled(true);
    w.addJavascriptInterface(new Object() {
      @JavascriptInterface
      public void copy(final String t) {
        runOnUiThread(new Runnable() { public void run() {
          ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
          cm.setPrimaryClip(ClipData.newPlainText("ascii art", t));
        }});
      }
      @JavascriptInterface
      public void share(final String t) {
        runOnUiThread(new Runnable() { public void run() {
          Intent i = new Intent(Intent.ACTION_SEND);
          i.setType("text/plain");
          i.putExtra(Intent.EXTRA_TEXT, t);
          startActivity(Intent.createChooser(i, "Share art"));
        }});
      }
    }, "Android");
    w.loadUrl("file:///android_asset/index.html");
    setContentView(w);
  }
}
